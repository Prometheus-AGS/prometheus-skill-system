---
license: MIT
name: kbd-child-exit
version: '1.0.0'
description: >
  Exit the active KBD child loop: write its handoff-out, roll its progress up to
  the parent node, pop the position path, and return control to the parent. The
  --enter companion descends into a selected child so new children nest under it.
metadata:
  tags: [process, orchestration, automation]
---

# /kbd-child-exit

Close the active child loop and return to the parent — the counterpart to
`/kbd-new-child`. With `--enter`, descend into the selected child instead.

## What this does

### exit (default)

1. Requires the active child to have a `reflection.md` (run `/kbd-reflect` for
   the child first; refuses otherwise).
2. Writes `handoff-out.md` in the child dir — deliverables, goal completion
   status, unresolved items, recommendations to the parent.
3. Rolls the child's progress up the ancestor chain via `shared/lib/rollup.sh`:
   each parent node's `progress.json` gains a `children{}` block
   (`status`, canonical implementation counters, legacy counter aliases,
   certification status, handoff, and completion timestamp).
4. Pops the last element of `path[]`, clears `childPointer`, and restores the
   parent's cursor — the parent loop resumes with the child's result visible.
5. Fires `child:after`.

### --enter

Descends into the currently selected `childPointer`: sets `path[]` to the child
chain and clears `childPointer`, so the next `/kbd-new-child` nests **under**
this child. Enter and exit are the child-navigation pair: select with
`/kbd-next-child`, descend with `/kbd-child-exit --enter`, return with
`/kbd-child-exit`.

## Progress Signals (MANDATORY)

Before any other action, emit:

```
Starting kbd-child-exit — <child chain>
```

When the child is closed (or entered), emit:

```
Completed kbd-child-exit — exited <child chain>
```

Use the canonical chain from `path[]`. Emit to plain response text.

## How to invoke

```sh
"$KBD_ORCHESTRATOR_ROOT/skills/kbd-child-exit/kbd-child-exit.sh"          # exit
"$KBD_ORCHESTRATOR_ROOT/skills/kbd-child-exit/kbd-child-exit.sh" --enter  # descend
```

Prerequisites: the waypoint `path[]` must have depth > 1 to exit; a
`childPointer` must be selected to `--enter`.

## Examples

```
/kbd-next-child auth-refactor      # select the child
/kbd-child-exit --enter            # descend into it (new children nest here)
# … run the inner loop, /kbd-reflect it …
/kbd-child-exit                    # write handoff-out, roll up, return to parent
```

## Hook integration

Fires `child:after` for the closing child. The opening `child:before` is fired
by `/kbd-new-child`. See orchestrator `SKILL.md` → "Hooks".

## Selected-method recovery and authority

Before dependent work, run the packaged `shared/method-context.mjs --project <project-root> --phase <canonical-phase-id> --write` from the resolved orchestrator root (or read its current phase-local method-context.md when a recovery surface cannot invoke Node). Resolve latest non-superseded canonical `KBD-METHOD` decision and adopted contract, then preserve the same references in role inputs, dispatch and handoff read order. See `references/method-context.md`. Missing/changed method, contract, calibration or supersession is explicit; a prior command/memory/tool inventory is not fresh authority.

For selected VLBV, define acceptance/scenarios before generation and complete the entire agreed value phase before generated-code verification. Executable authoring follows governing host policy. Task/hour/commit/reviewer requests, compiler problems and renamed slices create no new boundary. Surface host/skill conflicts before dependent actions; do not rewrite operator-owned policy or infer early-check permission. Preserve original evidence, source/build/configuration/fixture/candidate freshness, consumed budgets and unresolved effects. Reconcile uncertain effects before retry. Recovered instructions are instruction-only unless a named actual runtime/host boundary enforces them; no release or automatic-successor authority follows.
