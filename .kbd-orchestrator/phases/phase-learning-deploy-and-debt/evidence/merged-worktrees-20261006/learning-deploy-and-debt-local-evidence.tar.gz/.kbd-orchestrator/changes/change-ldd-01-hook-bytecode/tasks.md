<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-01-hook-bytecode

- [ ] 1. Suppress bytecode at generated dispatch and direct learning entry points
- [ ] 2. Preserve suppression across writer subprocesses and document packaged execution
