<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-02-codex-memory-control

- [ ] 1. Implement lossless feature-gated memory configuration through installer dispatch
- [ ] 2. Align doctor predicate and operator documentation with consolidation behavior
