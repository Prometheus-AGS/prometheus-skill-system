<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-03-published-memory-pins

- [ ] 1. Prepare the all-repository pin and release candidate manifest
- [ ] 2. Freeze exact compatible release identities and obtain protected-edit and tag approvals
- [ ] 3. Apply approved final gitlinks and coherent version declarations
