<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-04-cache-identity-accounting

- [ ] 1. Bind query caching to immutable provider/model identity while retaining the pinned cache
- [ ] 2. Correct attempt/reuse counters and explicit stats error behavior
