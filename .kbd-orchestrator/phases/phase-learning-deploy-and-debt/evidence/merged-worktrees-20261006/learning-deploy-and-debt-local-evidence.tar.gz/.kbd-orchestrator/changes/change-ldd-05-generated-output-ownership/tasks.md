<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-05-generated-output-ownership

- [ ] 1. Implement independent materialized-output ownership and consumer checks
