<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-06-installed-doctor-remediation

- [ ] 1. Resolve and quote a verified installed helper in doctor diagnostics
