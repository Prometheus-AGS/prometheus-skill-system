<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-07-custom-codex-home

- [ ] 1. Route installer subprocesses and projections through one effective Codex root
- [ ] 2. Align uninstall rollback pruning and doctor with custom-home ownership
