<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-08-bounded-cortex-mirror

- [ ] 1. Implement bounded cross-process admission and feeder lifetime ownership
- [ ] 2. Expose optional-mirror outcomes and document saturation and isolation
