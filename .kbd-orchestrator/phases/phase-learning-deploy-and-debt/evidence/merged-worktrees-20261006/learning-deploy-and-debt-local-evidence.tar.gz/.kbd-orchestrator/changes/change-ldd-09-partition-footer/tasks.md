<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-09-partition-footer

- [ ] 1. Compute the exact stable footer budget and preserve partition idempotence
