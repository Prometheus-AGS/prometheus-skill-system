<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-10-mini-executable-modes

- [ ] 1. Preserve packaged executable modes and detect mode drift in mini CLI
