<!-- GENERATED from tasks.json for the Spec artifact; edit tasks.json, not this view. -->

# Tasks — change-ldd-11-entrypoint-spec-contract

- [ ] 1. Add and route the production-entry-point acceptance template
