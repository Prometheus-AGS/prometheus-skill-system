<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-12-integration-rollout

- [ ] 1. Reconcile all generated outputs then author isolated product and documentation integration scenarios
- [ ] 2. Run the consolidated local product services sites and fresh-clone release gates
- [ ] 3. Complete independent cumulative review and confirm any batched fixes
- [ ] 4. Publish certified source including Companion and hand PRs to the user for merge
- [ ] 5. Apply approved machine rollout and publish certified documentation sites
- [ ] 6. Close evidenced historical obligations and record maintenance readiness with safe worktree cleanup

## Release-closure scope amendment

The owner expanded this phase to finish full/mini as stable products. This final boundary also covers changes 13-18, both Docusaurus production builds and locally served page/route/example checks, all content inventory dispositions, actual team/handoff/model recipes, Companion two-process and absent-service behavior, current mini production baseline and fresh remote clone/installability of every final pin. Do not run aggregate scripts that implicitly add unit suites as acceptance.

Companion check-in/push is explicitly authorized by the user; after local source/security/integration gates, stage only manifest-listed source, create the proposed private remote if needed, push and verify the remote commit/fresh clone. User-owned merges, versions.toml changes and tags retain their explicit boundaries. Publish site content only from merged locally certified identities. Do not merely prepare a repository without pushing it and call publication complete.

Reconcile the four historical control-plane changes through their existing canonical IDs only after the final evidence; preserve and explain missing-receipt provenance. Finish all in-scope release blockers, record maintenance readiness and remove merged worktrees only after checking live processes and marketplace references. Never alter deploy-main/deploy/main.
