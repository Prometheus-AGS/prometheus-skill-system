<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-13-source-convergence

- [ ] 1. Complete worktree branch dirty-source and archive disposition inventory
- [ ] 2. Converge full and mini source including merged hook fixes and task acceptance parity
- [ ] 3. Converge relevant dependency source and record final candidate provenance
