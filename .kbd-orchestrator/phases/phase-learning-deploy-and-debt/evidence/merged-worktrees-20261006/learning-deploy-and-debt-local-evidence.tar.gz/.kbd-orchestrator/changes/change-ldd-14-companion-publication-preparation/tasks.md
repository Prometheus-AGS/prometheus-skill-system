<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-14-companion-publication-preparation

- [ ] 1. Capture intended Companion source into an isolated publication candidate
- [ ] 2. Finish Companion integration packaging and replace starter documentation
- [ ] 3. Prepare explicit commit inventory remote destination and publication procedure
