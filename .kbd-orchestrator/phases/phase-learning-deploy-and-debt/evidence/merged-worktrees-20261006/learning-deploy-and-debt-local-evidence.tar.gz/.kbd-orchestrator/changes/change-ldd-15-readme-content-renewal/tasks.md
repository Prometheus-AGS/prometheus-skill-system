<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-15-readme-content-renewal

- [ ] 1. Audit all owned content and rewrite the full product README
- [ ] 2. Rewrite mini onboarding and reconcile both README families with final product state
