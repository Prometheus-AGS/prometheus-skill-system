<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-16-agent-team-handbook

- [ ] 1. Document team creation role ownership task lifecycle and native harness use
- [ ] 2. Document communication handoffs cross-project coordination and scoped memory
- [ ] 3. Document model assignment policy discovery budgets and harness limitations
