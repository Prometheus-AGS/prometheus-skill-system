<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-17-service-sites-current

- [ ] 1. Document service ownership repositories installation and recovery from actual contracts
- [ ] 2. Reconcile all site content canonical guides navigation redirects and catalogs
