<!-- GENERATED from tasks.json; edit the source ledger. -->

# Tasks — change-ldd-18-stability-legacy-closure

- [ ] 1. Map historical tasks blockers and boundary gaps to evidence-backed closure work
- [ ] 2. Finish migration and standalone versus connected control-plane source contracts
- [ ] 3. Write supported-product maintenance upgrade rollback and recovery contract
