#!/usr/bin/env python3
import json,subprocess
r=subprocess.run(["/Users/gqadonis/.local/bin/prometheus","kbd","--path","/Users/gqadonis/Projects/prometheus/prometheus-skill-pack","status","--json"],capture_output=True,text=True,check=True)
s=json.loads(r.stdout)
print(json.dumps({"source":"prometheus-kbd-status","revision":s["revision"],"phaseId":s["activePath"]["phaseId"],"phases":s["phases"],"dimensions":s["completion"],"completion":{"tasks":[f"{pid}/{cid}/{tid}" for pid,phase in s["phases"].items() for cid,c in phase["changes"].items() for tid,t in c["tasks"].items() if t["status"]=="complete"],"changes":[cid for phase in s["phases"].values() for cid,c in phase["changes"].items() if c["status"]=="complete"],"phases":[pid for pid,phase in s["phases"].items() if phase["status"]=="complete"]}}))
