#!/usr/bin/env bash
set -euo pipefail
# Operational deployment authorized by the owner goal, not a test gate.
# Every Cargo child checks existing machine-wide builds before launch.
cargo() {
  while pgrep -x cargo >/dev/null 2>&1 || pgrep -x rustc >/dev/null 2>&1; do
    printf 'Waiting for another Cargo/rustc build before this deployment component.\n' >&2
    sleep 20
  done
  command cargo "$@"
}
export -f cargo
export PYTHONDONTWRITEBYTECODE=1
exec bash /Users/gqadonis/.codex/skills/delivery-cadence/scripts/refresh-skill-pack.sh \
 --deploy /Users/gqadonis/Projects/prometheus/worktrees/ldd-machine-main \
 --state /Users/gqadonis/Projects/prometheus/worktrees/learning-deploy-and-debt/.prometheus/cadence-learning-deploy-and-debt/state.json \
 --mode auto \
 --services ai.prometheus.exec,ai.prometheus.surrealdb-native,ai.prometheus.surreal-memory-native,ai.prometheus.liter-llm-api,ai.prometheus.pk-cherry,ai.prometheus.learning-worker,ai.prometheus.surface-bridge \
 --receipt /Users/gqadonis/Projects/prometheus/worktrees/learning-deploy-and-debt/.kbd-orchestrator/phases/phase-learning-deploy-and-debt/evidence/cadence-machine-refresh.json
